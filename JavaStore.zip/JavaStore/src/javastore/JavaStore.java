package javastore;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Graphics;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class JavaStore extends JFrame {
    private static JavaStore store_store;
    private static long last_frame_time;
    private static Image stores;
    private static Image truba;
    private static Image hummer; 
    private static List<Hummer> hummers = new ArrayList<>(); 
    private static int score = 0;

    public static void main(String[] args) throws IOException {
        stores = ImageIO.read(JavaStore.class.getResourceAsStream("store.jpeg"));
        truba = ImageIO.read(JavaStore.class.getResourceAsStream("logo3.png"));
        hummer = ImageIO.read(JavaStore.class.getResourceAsStream("hummer.png")); 
        
        store_store = new JavaStore();
        store_store.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        store_store.setLocation(200, 50);
        store_store.setSize(900, 600);
        store_store.setResizable(false);
        last_frame_time = System.nanoTime();

        for (int i = 0; i < 3; i++) {
            hummers.add(new Hummer(Math.random() * store_store.getWidth(), -100, 200 + Math.random() * 100, 50 + Math.random() * 100));
        }

        StoreField library_field = new StoreField();
        store_store.add(library_field);
        store_store.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                for (Hummer h : hummers) {
                    if (x >= h.drop_left && x <= h.drop_left + 50 && y >= h.drop_top && y <= h.drop_top + 50) {
                        h.resetPosition();  
                        score++;
                        store_store.setTitle("Score: " + score);
                    }
                }
            }
        });
        store_store.setVisible(true);
    }

    public static void onRepaint(Graphics g) {
        long current_time = System.nanoTime();
        float delta_time = (current_time - last_frame_time) * 0.000000001f;
        last_frame_time = current_time;

        
        g.drawImage(stores, 0, 0, store_store.getWidth(), store_store.getHeight(), null);
        g.drawImage(truba, 50, 50, 100, 100, null);

        
        for (Hummer h : hummers) {
            h.updatePosition(delta_time, store_store.getWidth(), store_store.getHeight());
            g.drawImage(hummer, (int) h.drop_left, (int) h.drop_top, 50, 50, null);  
        }
    }

    public static class StoreField extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            onRepaint(g);
            repaint(); 
        }
    }

    
    public static class Hummer {
        double drop_left;
        double drop_top;
        double drop_v;  
        double horizontal_v;  

        public Hummer(double drop_left, double drop_top, double drop_v, double horizontal_v) {
            this.drop_left = drop_left;
            this.drop_top = drop_top;
            this.drop_v = drop_v;
            this.horizontal_v = horizontal_v;
        }

     
        public void updatePosition(float delta_time, int window_width, int window_height) {
            drop_top += drop_v * delta_time;
            drop_left += horizontal_v * delta_time;

    
            if (drop_top > window_height || drop_left < 0 || drop_left > window_width - 50) {
                resetPosition();
            }
        }

    
        public void resetPosition() {
            drop_top = -100;
            drop_left = Math.random() * (store_store.getWidth() - 50);  
            horizontal_v = 50 + Math.random() * 100;  
            drop_v = 200 + Math.random() * 100;  
        }
    }
}
